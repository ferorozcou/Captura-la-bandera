using UnityEngine;

public class CorrerBaseState : BuscarState
    // Start is called once before the first execution of Update after the MonoBehaviour is created
 public class CorrerBaseState : StateBuscador
{
    public RecuperarState(BuscadorController npc) : base(npc) { }

    public override void Enter()
    {
        npc.agent.isStopped = false;
    }

    public override void Update()
    {
        npc.agent.destination = npc.player.position;

        // Si pierde al jugador ? buscar
        if (npc.LifeRemaining() == 0)
        {
            npc.ChangeState(new MorirState(npc));
        }
    }

    public override void Exit() { }
}
}
