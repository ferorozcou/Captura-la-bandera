using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.AI;




public class NPC : MonoBehaviour
{


    public NavMeshAgent agent;
    public Transform player;

    public float visionRange = 10f;
    public float attackRange = 2f;

    public Vector3 lastKnownPosition;

    private IState currentState;

    void Start()
    {
        ChangeState(new PatrullarState());
    }

    void Update()
    {
        currentState?.Execute(this);
    }

    public void ChangeState(IState newState)
    {
        currentState?.Exit(this);
        currentState = newState;
        currentState.Enter(this);
    }




}
